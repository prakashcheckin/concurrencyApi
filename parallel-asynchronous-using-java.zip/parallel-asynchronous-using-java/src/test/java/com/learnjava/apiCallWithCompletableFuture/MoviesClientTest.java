package com.learnjava.apiCallWithCompletableFuture;

import com.learnjava.domain.movie.Movie;
import com.learnjava.util.CommonUtil;
import org.junit.jupiter.api.RepeatedTest;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class
MoviesClientTest {

    WebClient webClient = WebClient.builder()
            .baseUrl("http://localhost:3000/movies")
            .build();

    static ExecutorService executorService= Executors.newFixedThreadPool(50);

    MoviesClient moviesClient = new MoviesClient(webClient, executorService);

   @RepeatedTest(10)
   void retriveMoviesTest(){

       CommonUtil.startTimer();
       //given
       var movieInfoIds = List.of(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L);

       //when
       List<Movie> movies = moviesClient.retrieveMovies(movieInfoIds);
       CommonUtil.timeTaken();

       //then
        assert  movies != null;
        assert  movies.size() == 32;
   }


    @RepeatedTest(10)
    void retriveMoviesWithCfTest(){

        CommonUtil.startTimer();
        //given
        var movieInfoIds = List.of(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L);

        //when
        List<Movie> movies = moviesClient.retrieveMoviesWithcf(movieInfoIds);
        CommonUtil.timeTaken();

        //then
        assert  movies != null;
        assert  movies.size() == 32;
    }


    @RepeatedTest(10)
    void retriveMoviesWithCfTestWithOwnExecutorService(){

        CommonUtil.startTimer();
        //given
        var movieInfoIds = List.of(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L,
                5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L);

        //when
        List<Movie> movies = moviesClient.retrieveMoviesWithcfWithOwnExecutorService(movieInfoIds);
        CommonUtil.timeTaken();

        //then
        assert  movies != null;
        assert  movies.size() == 32;
    }

    @RepeatedTest(10)
    void retriveMoviesWithCfTestWithOwnExecutorServiceWithAllOf(){

        CommonUtil.startTimer();
        //given
        var movieInfoIds = List.of(1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L,1L, 2L, 3L, 4L,
                5L, 6L, 7L, 8L,1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L);

        //when
        List<Movie> movies = moviesClient.retrieveMoviesWithcfWithOwnExecutorServiceUsingAllOf(movieInfoIds);
        CommonUtil.timeTaken();

        //then
        assert  movies != null;
        assert  movies.size() == 32;
    }



}
