package com.learnjava.apiCallWithCompletableFuture;

import com.learnjava.domain.movie.Movie;
import com.learnjava.domain.movie.MovieInfo;
import com.learnjava.domain.movie.Review;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;

public class MoviesClient {

    private final WebClient webClient;

    private ExecutorService executorService;

    public MoviesClient(WebClient webClient, ExecutorService executorService) {
        this.webClient = webClient;
        this.executorService = executorService;
    }

    private List<Review> invokeReviewService(Long movieInfoId) {

        ///v1/reviews?movieInfoId=1
        var reviewUri = UriComponentsBuilder.fromUriString("/v1/reviews")
                //.queryParam("movieInfoId", movieInfoId)
                .buildAndExpand()
                .toString();

        return webClient
                .get()
                .uri(reviewUri)
                .retrieve()
                .bodyToFlux(Review.class)
                .collectList()
                .block();
    }

    public MovieInfo invokeMovieInfoService() {
        //var movieInfoUrlPath = "/v1/movie_infos/{movieInfoId}";
        var movieInfoUrlPath = "/v1/movie_infos";
        return webClient
                .get()
                //.uri(movieInfoUrlPath, movieInfoId)
                .uri(movieInfoUrlPath)
                .retrieve()
                .bodyToMono(MovieInfo.class)
                .block();
    }


    // Retrive Movies without any threads
    public List<Movie> retrieveMovies(List<Long> movieInfoIds){
        return movieInfoIds.stream()
                .map(movieId -> retrieveMovie(movieId))
                .collect(Collectors.toList());
    }

    public Movie retrieveMovie(Long movieInfoId) {
        var movieInfo =  invokeMovieInfoService();
        var reviews =  invokeReviewService(movieInfoId);
        return new Movie(movieInfo, reviews);
    }


    // Retrive Movies with CF
    public List<Movie> retrieveMoviesWithcf(List<Long> movieInfoIds){
        List<CompletableFuture<Movie>> collect = movieInfoIds.stream()
                .map(movieId -> {
                    CompletableFuture<Movie> movieCompletableFuture = CompletableFuture.supplyAsync(() -> retrieveMovieWithcf(movieId));
                    return movieCompletableFuture;
                })
                .collect(Collectors.toList());
        List<Movie> collect1 = collect.stream().map(movieCompletableFuture -> movieCompletableFuture.join()).collect(Collectors.toList());
        return collect1;
    }

    public Movie retrieveMovieWithcf(Long movieInfoId) {
        CompletableFuture<MovieInfo> movieInfoCompletableFuture = CompletableFuture.supplyAsync(() -> invokeMovieInfoService());
        CompletableFuture<List<Review>> listCompletableFuture = CompletableFuture.supplyAsync(() -> invokeReviewService(movieInfoId));
        return movieInfoCompletableFuture
                .thenCombine(listCompletableFuture, (movieInfo,reviews)->new Movie(movieInfo, reviews))
                .join(); //block the thread
    }


    // Retrive Movies with CF and executor service
    public List<Movie> retrieveMoviesWithcfWithOwnExecutorService(List<Long> movieInfoIds){
        List<CompletableFuture<Movie>> collect = movieInfoIds.stream()
                .map(movieId -> {
                    CompletableFuture<Movie> movieCompletableFuture = CompletableFuture.supplyAsync(() -> retrieveMovieWithcfWithOwnExecutorService(movieId), executorService);
                    return movieCompletableFuture;
                }).collect(Collectors.toList());
        List<Movie> movies = collect.stream().map(movieCompletableFuture -> movieCompletableFuture.join()).collect(Collectors.toList());
        return movies;
    }

    public Movie retrieveMovieWithcfWithOwnExecutorService(Long movieInfoId) {
        CompletableFuture<MovieInfo> movieInfoCompletableFuture = CompletableFuture.supplyAsync(() -> invokeMovieInfoService(), executorService);
        CompletableFuture<List<Review>> listCompletableFuture = CompletableFuture.supplyAsync(() -> invokeReviewService(movieInfoId), executorService);
        return movieInfoCompletableFuture
                .thenCombine(listCompletableFuture, (movieInfo,reviews)->new Movie(movieInfo, reviews)).join();
    }

    // Retrive Movies with CF and own executor service. using all of
    public List<Movie> retrieveMoviesWithcfWithOwnExecutorServiceUsingAllOf(List<Long> movieInfoIds){

        List<CompletableFuture<Movie>> collect = movieInfoIds.stream()
                .map(movieId -> {
                    CompletableFuture<Movie> movieCompletableFuture = CompletableFuture.supplyAsync(() -> retrieveMovieWithcfWithOwnExecutorServiceUsingAllOf(movieId), executorService);
                    return movieCompletableFuture;
                }).collect(Collectors.toList());


        // this join method blocks the thread. We can use the allof method. this all of method will get executed only after all comleptable future got completd.
        CompletableFuture<Void> voidCompletableFuture = CompletableFuture.allOf(collect.toArray((new CompletableFuture[collect.size()])));
        List<Movie> movies = voidCompletableFuture.thenApply(unused -> collect.stream().map(movieCompletableFuture -> movieCompletableFuture.join()).collect(Collectors.toList())).join();
        return movies;
    }

    public Movie retrieveMovieWithcfWithOwnExecutorServiceUsingAllOf(Long movieInfoId) {
        CompletableFuture<MovieInfo> movieInfoCompletableFuture = CompletableFuture.supplyAsync(() -> invokeMovieInfoService(), executorService);
        CompletableFuture<List<Review>> listCompletableFuture = CompletableFuture.supplyAsync(() -> invokeReviewService(movieInfoId), executorService);
        return movieInfoCompletableFuture
                .thenCombine(listCompletableFuture, (movieInfo,reviews)->new Movie(movieInfo, reviews)).join();
    }





}
